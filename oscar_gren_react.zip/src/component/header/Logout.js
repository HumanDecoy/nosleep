import React from 'react';
import HighButton from './HighButton.js';
const LogoutButton = (props) => {
    return(
  <HighButton className="darkred"  {...props}/>
    )
}

export default LogoutButton;